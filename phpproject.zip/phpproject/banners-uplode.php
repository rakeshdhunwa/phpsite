<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Img upload</title>
</head>
<body>
    <form action="#" method="post" enctype="multipart/form-data">
        <input type="file" name="uploadfile" value=""><br><br>

        <input type="submit" name="submit">
    </form>
</body>
</html>
<?php

$filename = $_FILES["uploadfile"]["name"];
$tmpname = $_FILES["uploadfile"]["tmp_name"];
$folder = "img/".$filename;
echo $folder;
move_uploaded_file($tmpname,$folder);
echo "<img src='$folder' height='100px' width='100px'>";
?>

