



<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                <h2 style="font-size:40px;">Banner Data</h2>
                    <?php
                    include_once('message.php');
                            
                        try{
                            $bannerSelect = "SELECT * FROM `banners`";
                            $bannerQuery = $conn->query($bannerSelect);
                        ?>
                            <button><a href="banners-form.php">Add New Data</a></button><br>
                            
                            <?php include_once('message.php');?>
                            <table border>
                                <tr>
                                    <th>Id</th>
                                    <th>Title</th>
                                    <th>Image</th>
                                    <th>Created Date</th>
                                    <th colspan="2">Action</th>
                                </tr>
                                <?php
                                    $i = 1;
                                    while($bannersData = $bannerQuery->fetch_assoc()){
                                ?>
                                        <tr>
                                            <td><?=$i++?></td>
                                            <td><?=$bannersData['title']?></td>
                                           <td> <div class="banner-imgData"><img src="<?=$bannersData['image']?>"></div></td>
                                            <td><?=$bannersData['created_at']?></td>
                                            <td><button id="edit"><a href="banners-edit.php?id=<?=$bannersData['id']?>">Edit</a></button></td>
                                            <td><button id="delete"><a href="banners-delete.php?id=<?=$bannersData['id']?>">Delete</a></button></td>
                                        </tr>
                                <?php
                                    }
                                ?>
                            </table>
                        <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                        ?>
                </div>
            </section>
        </div>
    </div>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>