<?php
    session_start();
    
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "project";
        
    try{
        // if(!(isset($_SESSION['email']) and isset($_SESSION['password']))){
        //     header("location: index.php");
        // }
        $pass = $_SESSION['password'];
        if($pass){

        }else{
            header("location: index.php");  
        }

        
        $conn = mysqli_connect($host,$username,$password,$dbname);  
    }catch(Exception $e){
        echo $e->getMessage();
    }




?>