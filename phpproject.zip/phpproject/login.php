<?php
    include_once('config.php');

    $email = $_REQUEST['email'];
    $password = $_REQUEST['password'];
    

    $passSelete = "SELECT * FROM `users` WHERE email='$email'AND password='$password'";
    $passQuery = $conn->query($passSelete);

    if($passQuery->num_rows){
        $pass = $passQuery->fetch_assoc();

        if($pass){

            $_SESSION['email'] = "Welcome ". "$email";
            $_SESSION['password'] =  "$password";
            header('location:dashboard.php');

        }else{
            header('location:index.php'); 
            $_SESSION['error'] = "please enter confirm password and email.... ";
        }

    }else{
        header('location:index.php');
        $_SESSION['error'] = "please enter confirm password and email.... ";

    }





?>