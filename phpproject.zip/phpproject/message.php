<link rel="stylesheet" href="style.css">
<?php
    if(isset($_SESSION['success'])){
?>
    <div class="success"><?=($_SESSION['success']);?></div>

<?php
    unset($_SESSION['success']);
    }
?>

<?php
    if(isset($_SESSION['error'])){
?>
    <div class="error"><?=($_SESSION['error']);?></div>

<?php
    unset($_SESSION['error']);
    }
?>

<?php
    if(isset($_SESSION['email'])){
?>
    <div class="success"><?=($_SESSION['email']);?></div>

<?php
    unset($_SESSION['email']);
    }
?>