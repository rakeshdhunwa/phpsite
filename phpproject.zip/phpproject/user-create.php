<?php
    include_once('config.php');
    try{
        $usdata = $_REQUEST;
        $name = $usdata['name'];
        $email = $usdata['email'];
        $password = $usdata['password'];
    
        $emailpass = "SELECT * FROM `users` WHERE email='$email'";
        $emailData = $conn->query($emailpass);

        if($emailData->num_rows){
            header('location:users-edit.php');
            $_SESSION['error'] = "Email id already exists";
        }else{
            if($_SERVER['REQUEST_METHOD']=='POST' && isset($usdata['submit'])){
                $inQuery = "INSERT INTO users(`name`,`email`,`password`)VALUES('$name','$email','$password')";
                $conn->query($inQuery);
                header('location:users-list.php');
                $_SESSION['success'] = "Data Add Successfully....";
            }
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }
?>