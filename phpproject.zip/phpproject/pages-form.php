<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                    <?php
                    include_once('message.php');
                    ?>
                     <h2 style="font-size:40px;">Page From</h2>
                    <div class="form">
                        <form action="pages-create.php" method="post">
                            <label for="title">Name</label><br>
                            <input type="text" name="page_name" value="" id="title" placeholder="Name"><br>

                            <label for="image">Url</label><br>
                            <input type="url" name="page_url" value="" placeholder="https://example.com"><br>

                            <label for="">Description</label><br>
                            <textarea name="description" id="editor" placeholder="Description">
                            &lt;p&gt;&lt;/p&gt;

                            </textarea><br><br>
                            <input type="submit" name="save" value="Save">
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>
     <!-- editer -->

     <script>
                ClassicEditor
                    .create( document.querySelector( '#editor' ) )
                    .catch( error => {
                        console.error( error );
                    } );
    </script>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>