<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                <h2 style="font-size:40px;">Pages Data</h2>
                    <?php
                    include_once('message.php');
                        $pagesSelete = "SELECT * FROM `pages`";
                        $pageQuery = $conn->query($pagesSelete);
                    ?>
                        <button><a href="pages-form.php">Add New Data</a></button><br>
                        <?php include_once('message.php');?><br><br>
                    <table border>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Url</th>
                            <th>Description</th>
                            <th>Created Date</th>
                            <th colspan="2">Action</th>
                        </tr>
                        <?php
                            while($data = $pageQuery->fetch_assoc()){
                        ?>      
                            <tr>
                                <td><?=$data['id']?></td>
                                <td><?=$data['name']?></td>
                                <td><?=$data['url']?></td>
                                <td><?=$data['description']?></td>
                                <td><?=$data['created_at']?></td>
                                <td><button id="edit"><a href="pages-edit.php?id=<?=$data['id']?>">Edit</a></button></td>
                                <td><button id="delete"><a href="pages-delete.php?id=<?=$data['id']?>">Delete</a></button></td>
                            </tr>
                        <?php
                            }
                    ?>
                    </table>
                </div>
            </section>
        </div>
    </div>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>