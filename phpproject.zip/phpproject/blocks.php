<!DOCTYPE html>
<html lang="en">
    <?php include_once('config.php');?>
<head>
  <?php include_once('head.php')?>
</head>
<body>
    <?php include_once('home-header.php');?><br><br><br><br><br><br><br><br>
    <?php
    $sqlblock = "SELECT * FROM `blocks` ORDER BY id DESC";
    $blocks = $conn->query($sqlblock);
    while($block = $blocks->fetch_assoc()){
    ?>
    <div class="post">
        <div><?=$block['name']?></div>
        <div><?=$block['identifire']?></div>
        <div><?=$block['description']?></div>
    </div>
    <?php
    }
//   print_r($page);
    ?>
    

    <!-- <div class="container" style="margin-top:130px;">
    
        <div class="owl-carousel owl-theme slider">
           
            <div class="item">
                <img src="img/multitv-customer-trust-1.png" alt="">
                <h3 class="font-36">Apollo24|7</h3>
                <p>“As Apollo 24|7, we have been associated with Multi-TV, doing our online property/show “Health Hour”. The service and technical support received from Multi-TV is exceptional.”</p>
                <h4>Kushagr Sharma</h4>
				<span>Marketing Manager Apollo24|7</span>
            </div>
            
            <div class="item">
                <img src="img/multitv-customer-trust-2.png" alt="">
                <h3 class="font-36">Samsung F62</h3>
                <p>“Thanks for your efforts on the F62 launch. It was executed very well, from the production to simulcast on multiple platforms. It is great to have MultiTV with us. I look forward to more opportunities of working together.”</p>
                <h4>Ram Deshpande</h4>
				<span>Vice-President, Digital Samsung</span>
            </div>
            <div class="item">
                <img src="img/multitv-customer-trust-3.png" alt="">
                <h3 class="font-36">Jk Tyre</h3>
                <p>"I have worked with Multitv on ‘N’ number of webcast projects till now it has been great working with Team Multitv, as they take complete ownership of the project that they do and they are really experts of their domain and that’s their USP as well.</p>
                <h4>Dhruv Tuteja (JK Tyre)</h4>
				<span>Manager Digital Marketing JK Tyres</span>
            </div>  
        </div>
        <div>
        <?= $page['description']?>
    </div>
        <div class="session">
            <!-- <ul>
                <li>
                    <img src="img/feture-1.jpg" alt="">
                    <h4>Hybrid/Virtual Events Platform</h4>
                    <p>Fully-managed, feature-rich platform that delivers immersive hybrid/virtual events to attendees...</p>
                </li>
                <li>
                    <img src="img/feture-2.jpg" alt="">
                    <h4>All-in-one OTT Solution</h4>
                    <p>Completely featured OTT platform to deliver enterprise video content to audience across the globe...</p>
                </li>
                <li>
                    <img src="img/feture-3.jpg" alt="">
                    <h4>Security & Privacy</h4>
                    <p>Securely host and broadcast your events with Built-in DRM, Watermarking, Single Sign On(SSO), VPN Detection, Geo-Blocking</p>
                </li>
                <li>
                    <img src="img/feture-4.jpg" alt="">
                    <h4>Support</h4>
                    <p>Get Designated Account Manager, complete Technical and end-user support till event completion.</p>
                </li>
                <li>
                    <img src="img/feture-5.jpg" alt="">
                    <h4>Monetizations</h4>
                    <p>Grow your revenue by monetizing hybrid/virtual events through pay-per-view, video advertising or subscription model...</p>
                </li>
                <li>
                    <img src="img/feture-6.jpg" alt="">
                    <h4>Customization</h4>
                    <p>Create customized, own branded events for you with Live Chroma and Hybrid Shoot, virtual main hall, lobby, auditorium...</p>
                </li>
                <li>
                    <img src="img/feture-7.jpg" alt="">
                    <h4>Attendee experience</h4>
                    <p>Deliver engaging attendee experience with interactive targeted networking, unlimited concurrent live video sessions...</p>
                </li>
                <li>
                    <img src="img/feture-8.jpg" alt="">
                    <h4>Analytics</h4>
                    <p>Track your event via Real-time Analytics dashboard, UTM source tracking, livestream analytics...</p>
                </li>
            </ul> -->
        </div> 
       
    </div>
   <?php include_once('footer.php');?>
   
   
</body>
</html>