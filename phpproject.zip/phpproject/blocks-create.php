<?php
    include_once('config.php');

   try{
        $blockdata = $_REQUEST;

        $block_name = $blockdata['block_name'];
        $identifire = $blockdata['identifire'];
        $description = $blockdata['description'];


        if(isset($_REQUEST['save'])){
            $bannerInsert = "INSERT INTO `blocks`(`name`,`identifire`,`description`)VALUES('$block_name','$identifire','$description')";
            $conn->query($bannerInsert);
            header('location:blocks-list.php');
            $_SESSION['success'] = "Data Add Successfully....";
        }else{
            $_SESSION['error'] = "Data Add Error....";
        }


   }catch(Exception $e){
    echo $e->getMessage();
   }

?>