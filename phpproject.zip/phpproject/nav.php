<nav>    
    <div class="logo"><img src="logo-1.png" alt=""></div>
    <h3>Management</h3>
        <ul>
            <li id="first"><a href="dashboard.php"><ion-icon name="grid-outline"></ion-icon>Dashboard</a></li>
            <li><a href="banners-list.php"><ion-icon name="document-outline"></ion-icon>Banners</a></li>
            <li><a href="users-list.php"><ion-icon name="journal-outline"></ion-icon>User</a></li>
            <li><a href="blocks-list.php"><ion-icon name="cart"></ion-icon>Blocks</a></li>
            <li><a href="pages-list.php"><ion-icon name="sync"></ion-icon>Pages</a></li>
        </ul>
        <hr>
        <h3>Connection</h3>
        <ul>
            <li><a href="#"><ion-icon name="chatbubble-ellipses-outline"></ion-icon>City</a></li>
            <li><a href="home.php" target= "blank"><ion-icon name="server-outline"></ion-icon>View Site</a></li>
            <li><a href="#"><ion-icon name="mail-outline"></ion-icon>Email integration</a></li>
        </ul>
        <hr>
        <h3>Customer</h3>
        <ul>
            <li><a href="#"><ion-icon name="git-compare-outline"></ion-icon>Transaction</a></li>
            <li><a href="#"><ion-icon name="settings-outline"></ion-icon>Maintenance</a></li>
        </ul>     
</nav>