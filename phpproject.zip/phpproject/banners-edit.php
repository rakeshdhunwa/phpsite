





<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                <h2 style="font-size:40px;">Welcome Dashboard</h2>
                    <?php
                    include_once('message.php');
                    ?>
                    <?php
                        try{
                            $id = $_REQUEST['id'];
                            $bannerEdit = "SELECT * FROM `banners` WHERE id=$id";
                            $bannerdata = $conn->query($bannerEdit);

                            $data = $bannerdata->fetch_assoc();
                        }catch(Exception $e){
                                echo $e->getMessage();
                        }
                    ?>

                        <div class="form">
                            <form action="banners-update.php" method="post">
                            <input type="hidden" name="id" value="<?=$data['id']?>">

                                <label for="title">Title</label><br>
                                <input type="text" name="banner_title" value="<?=$data['title']?>" id="title" placeholder="Title"><br>

                                <label for="image">Image</label><br>
                                <input type="file" name="banner_image" value="<?=$data['image']?>" placeholder="Image"><br>

                                <input type="submit" name="update" value="Update">
                            </form>
                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>



