<?php
    include_once('config.php');

    $sqlpage = "SELECT * FROM `blocks` WHERE id=10";
    $pages = $conn->query($sqlpage);

    $page = $pages->fetch_assoc();
    
//   print_r($page);


?>
<div>
    <?= $page['description']?>
</div>