<?php
    include_once('config.php');

   try{
            $bannerdata = $_REQUEST;

            $filename = $_FILES["uploadfile"]["name"];
            $tmpname = $_FILES["uploadfile"]["tmp_name"];
            $folder = "img/".$filename;
            //echo $folder;
            move_uploaded_file($tmpname,$folder);

        $banner_title = $bannerdata['banner_title'];
        //$banner_image = $bannerdata['banner_image'];

        if(isset($_REQUEST['save'])){
            $bannerInsert = "INSERT INTO `banners`(`title`,`image`)VALUES('$banner_title','$folder')";
            $conn->query($bannerInsert);
            header('location:banners-list.php');
            $_SESSION['success'] = "Data Add Successfully....";
        }else{
            $_SESSION['error'] = "Data Add Successfully....";
        }


   }catch(Exception $e){
    echo $e->getMessage();
   }

?>