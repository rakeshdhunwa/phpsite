<?php
    include_once('config.php');
    $userdata = $_REQUEST;
    $id = $userdata['id'];
    $name = $userdata['name'];
    $email = $userdata['email'];
    $password = $userdata['password'];

    include_once('message.php');
       
    try{      
        $pass = "SELECT * FROM `users` WHERE email='$email' AND id!=$id";
        $emailpass = $conn->query($pass);

        if($emailpass->num_rows > 0){
            header('location:users-edit.php?id='.$id);
        }else{
            if($_SERVER['REQUEST_METHOD']=='POST'){             
                $userupQuery = "UPDATE users SET name='$name',email='$email',password='$password' WHERE id=$id";
                $conn->query($userupQuery);
                header('location:users-list.php');
            }else{
                header('location:users-list.php');
            }
        }       
    }catch(Exception $e){
        echo $e->getMessage();
    }
 
?>