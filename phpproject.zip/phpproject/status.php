<!-- <?php
    include_once('config.php');
    print_r($_GET);
    die();
    $id $_GET['id'];
    $status = $_GET['status'];

    $Sql = "UPDATE `blocks` SET status='$status' WHERE id=$id";
    $conn->query($Sql);

    header('location:blocks-list.php');



?> -->