    





<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                    <?php
                    include_once('message.php');
                    ?><br>
                     <h2 style="font-size:40px;">Banner From</h2>
                    <div class="form">
                            <form action="banners-create.php" method="post" enctype="multipart/form-data">
                                <label for="title">Title</label><br>
                                <input type="text" name="banner_title" value="" id="title" placeholder="Title"><br>

                                <label for="image">Image</label><br>
                                <input type="file" name="uploadfile" value=""><br>

                                <input type="submit" name="save" value="Save">
                            </form>
                        </div>
                </div>
            </section>
        </div>
    </div>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>



