<?php
    include_once('config.php');

    try{
        $id = $_REQUEST['id'];
        if($id){
            $blockDelete = "DELETE FROM `blocks` WHERE id=$id";
            $conn->query($blockDelete);
            header('location:blocks-list.php');
            $_SESSION['success'] = "Data Delete Successfully....";
        }else{
            header('location:blocks-list.php');
            $_SESSION['error'] = "Error....";
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }





?>