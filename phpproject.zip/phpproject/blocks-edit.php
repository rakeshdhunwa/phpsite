<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                <h2 style="font-size:40px;">Welcome Dashboard</h2>
                    <?php
                    include_once('message.php');
                    ?>
                <?php
                    include_once('config.php');

                try{
                    $id = $_REQUEST['id'];
                    $blockEdit = "SELECT * FROM `blocks` WHERE id=$id";
                    $blockData = $conn->query($blockEdit);
                    $data = $blockData->fetch_assoc();
                ?>
                            <div class="form">
                                <form action="blocks-update.php" method="post">
                                <input type="hidden" name="id" value="<?=$data['id']?>"><br>


                                    <label for="title">Name</label><br>
                                    <input type="text" name="block_name" value="<?=$data['name']?>" id="title" placeholder="Name"><br>

                                    <label for="image">Identifire</label><br>
                                    <input type="text" name="identifire" value="<?=$data['identifire']?>" placeholder="Identifire"><br>

                                    <label for="">Description</label><br>
                                    <textarea name="description" ><?=$data['description']?></textarea><br><br>

                                    <input type="submit" name="save" value="Save">
                                </form>
                            </div>
                        <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                ?>
                </div>
            </section>
        </div>
    </div>
    <script>
            CKEDITOR.replace( 'description' );
        </script>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>



