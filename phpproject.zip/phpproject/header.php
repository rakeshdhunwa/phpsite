<div class="header-1">
    <div class="mobilemenu">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <h2>Overview</h2>
        <ul>
            <li><a href="#"><i class="fa-regular fa-bell"></i></a></li>
            <li ><a href="#"><img src="img/rd.jpg" alt="" style="margin-top:-5px;border-radius: 50px;"></a></li>
            <li><a href="#">Administrator<ion-icon name="chevron-down"></ion-icon></a>
                <ul class="dropdown">
                    <li><a href="#">admin</a></li>
                    <li><a href="#">admin</a></li>
                    <li><a href="#">admin</a></li>
                </ul>
            </li>
                <li><a href="logout.php"><ion-icon name="log-out-outline" style="margin-right:5px;"></ion-icon>Logout</a></li>
            </ul>
</div>