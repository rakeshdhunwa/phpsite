






<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                <h2 style="font-size:40px;">Welcome Dashboard</h2>
                    <?php include_once('message.php');?>
                    <?php
                      
                        try{
                            $id = $_REQUEST['id'];

                            $pageEdit = "SELECT * FROM `pages` WHERE id=$id";
                            $pageQuery = $conn->query($pageEdit);
                            $data = $pageQuery->fetch_assoc();
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                    ?>
                        <div class="form">
                            <form action="pages-update.php" method="post">
                            <input type="hidden" name="id" value="<?=$data['id']?>"><br>


                                <label for="title">Name</label><br>
                                <input type="text" name="page_name" value="<?=$data['name']?>" id="title" placeholder="Name"><br>

                                <label for="image">Url</label><br>
                                <input type="url" name="page_url" value="<?=$data['url']?>" placeholder="Url"><br>
                                <label for="">Description</label><br>
                                <textarea name="description" id="editor" placeholder="Description">
                                <?=$data['description']?>
                                &lt;p&gt;&lt;/p&gt;
                                </textarea><br><br>
                                <input type="submit" name="save" value="Save">
                            </form>
                        </div>
                </div>
            </section>
        </div>
    </div>

     <!-- editer -->

     <script>
                ClassicEditor
                    .create( document.querySelector( '#editor' ) )
                    .catch( error => {
                        console.error( error );
                    } );
    </script>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>



