<?php
    include_once('config.php');

    $banupdate = $_REQUEST;

    $id = $banupdate['id'];
    $banner_title = $banupdate['banner_title'];
    $banner_image = $banupdate['banner_image'];

    if(isset($_REQUEST['update'])){
        $bannerUpdate = "UPDATE `banners` SET title='$banner_title',image='$banner_image' WHERE id=$id";
        $conn->query($bannerUpdate);
        header('location:banners-list.php');
        $_SESSION['success'] = "Data Update Successfully.....";

    }else{
        header('location:banners-edit.php');
       
    }
?>