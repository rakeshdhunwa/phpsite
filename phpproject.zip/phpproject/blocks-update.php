<?php
    include_once('config.php');


    try{

        $blockdata = $_REQUEST;

        $id = $blockdata['id'];
        $block_name = $blockdata['block_name'];
        $identifire = $blockdata['identifire'];
        $description = $blockdata['description'];
       


        $blockUpdate = "UPDATE `blocks` SET name='$block_name',identifire='$identifire',description='$description' WHERE id=$id";
        $conn->query($blockUpdate);

        header('location:blocks-list.php');

    }catch(Exception $e){
        echo $e->getMessage();
    }




?>