<?php
    include_once('config.php');

    $id = $_REQUEST['id'];
   try{
        if($id){
            $usdelQuery = "DELETE FROM users WHERE id=$id";
            $conn->query($usdelQuery);
            header('location:users-list.php');
            $_SESSION['success'] = "Data Delete Successfully";
        }else{
            $_SESSION['error'] = "Data Delete Successfully";
        }
   }catch(Exception $e){
    echo $e->getMessage();
}

?>