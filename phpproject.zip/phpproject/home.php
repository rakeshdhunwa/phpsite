<!DOCTYPE html>
<html lang="en">
    <?php include_once('config.php');?>
<head>
  <?php include_once('head.php')?>
</head>
<body>
    <?php include_once('home-header.php');?>

    <div class="container">
        <?php 
            $sql = "SELECT * FROM `banners` ORDER BY id DESC";
            $banner_image = $conn->query($sql);
            ?>
            <div class="owl-carousel owl-theme banner">
                <?php
                    while($banner = $banner_image->fetch_assoc()){
                ?>
                <div class="item"> 
                    <img src="<?=$banner['image']?>" alt="">
                    <div class="title">
                        <h2><?=$banner['title']?></h2>
                    </div>
                </div>
        <?php
            }
        ?>
        </div>

        <?php

            $blockSqli = "SELECT * FROM `blocks`";
            $blockData = $conn->query($blockSqli);
        ?>
         <div class="post">
        <?php
            while($bData = $blockData->fetch_assoc()){
            ?>
                <div class="post-2">
                    <h2><?= $bData['name']?></h2>
                    <p><?= $bData['identifire']?></p>
                    <p><?= htmlspecialchars_decode($bData['description'])?></p>
                </div>    
            
            <?php
            }
            ?>
             </div>
        
    </div>
    
   <?php include_once('footer.php');?>

    <script>
        $('.owl-carousel').owlCarousel({
            loop:true,
            margin:10,
            nav:true,
            autoplay:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        })
    </script>
</body>
</html>