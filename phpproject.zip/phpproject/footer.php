<footer>
        <div class="footer-logo">
            <img src="img/header-logo.png" alt="">
        </div>
        <div class="footer-logo-2">
            <ul>
                <li><img src="img/footer-logos-1.png" alt=""></li>
                <li><img src="img/footer-logos-2.png" alt=""></li>
                <li><img src="img/footer-logos-3.png" alt=""></li>
                <li><img src="img/footer-logos-4.png" alt=""></li>
                <li><img src="img/footer-logos-5.png" alt=""></li>
            </ul>
            <p>2022 © Tech Zento Solution Pvt. Ltd 2022 - All Rights Reserved</p>
        </div>
    </footer>