<?php
    include_once('config.php');

    $id = $_REQUEST['id'];
    
    try{
        if($id){
            $pageDelete = "DELETE FROM `pages` WHERE id=$id";
            $conn->query($pageDelete);
            header('location:pages-list.php');
            $_SESSION['success'] = "Data Delete Successfully....";
        }else{
            $_SESSION['error'] = "Error";
        }
    
    }catch(Exception $e){
        echo $e->getMessage();
    }




?>