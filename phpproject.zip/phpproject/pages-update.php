<?php
    include_once('config.php');

    $pagesData = $_REQUEST;
    $id = $pagesData['id'];
    $page_name =$pagesData['page_name'];
    $page_url =$pagesData['page_url'];
    $description =$pagesData['description'];
    

 if(isset($_REQUEST['save'])){
    $pageUpdate = "UPDATE `pages` SET name='$page_name',url='$page_url',description='$description' WHERE id=$id";
    $conn->query($pageUpdate);
    header('location:pages-list.php');
    $_SESSION['success'] = "Data Update Successfully.....";
 }else{
    $_SESSION['error'] = "Error";
 }




?>