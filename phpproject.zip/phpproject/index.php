<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="stylesheet" href="login.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js" integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <script src="https://unpkg.com/ionicons@latest/dist/ionicons.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
	</head>
	<body>
		<div class="login">
			<h1>Login</h1>
		 <?php include_once('message.php');?> 
			<form action="login.php" method="post" id="datasave">
				<label for="useremail">
					<i class="fas fa-user"></i>
				</label>
				<input type="text" name="email" placeholder="Useremail" id="useremail" required>
				<label for="password"><br>
					<i class="fas fa-lock"></i>
				</label>
				<input type="password" name="password" placeholder="Password" id="password" required><br>
                <a href="">Forget Me?</a>
				<input type="submit" value="Login">
			</form>
		</div>
	</body>
</html>

