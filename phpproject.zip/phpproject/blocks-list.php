<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                <h2 style="font-size:40px;">Blocks Data</h2>
                    <?php
                    include_once('message.php');
                        try{      
                            $blockSelete = "SELECT * FROM `blocks`";
                            $blockQuery = $conn->query($blockSelete);
                    ?>
                        <button><a href="blocks-form.php">Add New Data</a></button><br>
                        <?php include_once('message.php');?>
                    <table border>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Identifire</th>
                            <th>Description</th>
                            <th>Created Date</th>
                            <th colspan="2">Action</th>
                        </tr>
                        <?php
                                $i =1;
                                while($blockData = $blockQuery->fetch_assoc()){
                        ?>
                                    <tr>
                                        <td><?=$i++?></td>
                                        <td><?=$blockData['name']?></td>
                                        <td><?=$blockData['identifire']?></td>
                                        <td><?=$blockData['description']?></td>
                                        <td><?=$blockData['created_at']?></td>
                                        <td><button id="edit"><a href="blocks-edit.php?id=<?=$blockData['id']?>">Edit</a></button></td>
                                        <td><button id="delete"><a href="blocks-delete.php?id=<?=$blockData['id']?>">Delete</a></button></td>
                                    </tr>
                        <?php
                                }
                            }catch(Exception $e){
                                echo $e->getMessage();
                            }
                        ?>
                    </table>
                </div>
            </section>
        </div>
    </div>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>