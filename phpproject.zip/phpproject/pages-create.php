<?php
    include_once('config.php');

    $pageData = $_REQUEST;

   try{
        $page_name =$pageData['page_name'];
        $page_url =$pageData['page_url'];
        $description =$pageData['description'];

        if(isset($_REQUEST['save'])){
            $pageInsert = "INSERT INTO `pages` (`name`,`url`,`description`)VALUES('$page_name','$page_url','$description')";
        $conn->query($pageInsert);
        header('location:pages-list.php');
        $_SESSION['success'] = "Data Create Successfully....";
        }else{
            $_SESSION['error'] = "Error....";

        }

   }catch(Exception $e){
        echo $e->getMessage();
   }


?>