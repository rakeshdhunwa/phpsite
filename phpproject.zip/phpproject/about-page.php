<!DOCTYPE html>
<html lang="en">
    <?php include_once('config.php');?>
<head>
  <?php include_once('head.php')?>
</head>
<body>
    <?php include_once('home-header.php');?>
    <div class="container" style="margin-top:130px;">
    <div class="session">
            <ul>
                <li>
                    <img src="img/feture-1.jpg" alt="">
                    <h4>Hybrid/Virtual Events Platform</h4>
                    <p>Fully-managed, feature-rich platform that delivers immersive hybrid/virtual events to attendees...</p>
                </li>
                <li>
                    <img src="img/feture-2.jpg" alt="">
                    <h4>All-in-one OTT Solution</h4>
                    <p>Completely featured OTT platform to deliver enterprise video content to audience across the globe...</p>
                </li>
                <li>
                    <img src="img/feture-3.jpg" alt="">
                    <h4>Security & Privacy</h4>
                    <p>Securely host and broadcast your events with Built-in DRM, Watermarking, Single Sign On(SSO), VPN Detection, Geo-Blocking</p>
                </li>
                <li>
                    <img src="img/feture-4.jpg" alt="">
                    <h4>Support</h4>
                    <p>Get Designated Account Manager, complete Technical and end-user support till event completion.</p>
                </li>
                <li>
                    <img src="img/feture-5.jpg" alt="">
                    <h4>Monetizations</h4>
                    <p>Grow your revenue by monetizing hybrid/virtual events through pay-per-view, video advertising or subscription model...</p>
                </li>
                <li>
                    <img src="img/feture-6.jpg" alt="">
                    <h4>Customization</h4>
                    <p>Create customized, own branded events for you with Live Chroma and Hybrid Shoot, virtual main hall, lobby, auditorium...</p>
                </li>
                <li>
                    <img src="img/feture-7.jpg" alt="">
                    <h4>Attendee experience</h4>
                    <p>Deliver engaging attendee experience with interactive targeted networking, unlimited concurrent live video sessions...</p>
                </li>
                <li>
                    <img src="img/feture-8.jpg" alt="">
                    <h4>Analytics</h4>
                    <p>Track your event via Real-time Analytics dashboard, UTM source tracking, livestream analytics...</p>
                </li>
            </ul>
        </div>
       
    </div>
   <?php include_once('footer.php');?>
   
    <script>
        $('.owl-carousel').owlCarousel({
            loop:true,
            margin:10,
            nav:true,
            autoplay:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                },
                1000:{
                    items:3
                }
            }
        })
    </script>
</body>
</html>