<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>

</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner-first">
            <section>
                <div class="banner-second"><br><br>
                <div id="data"></div><br><br>
                    <?php
                    include_once('message.php');
                    ?>
                     <h2 style="font-size:40px;">Blocks From</h2>
                    <div class="form">
                        <form action="blocks-create.php" method="post">
                            <label for="title">Name</label><br>
                            <input type="text" name="block_name" value="" id="title" placeholder="Title"><br>

                            <label for="image">Identifire</label><br>
                            <input type="text" name="identifire" value="" placeholder="Identifire"><br>

                            <label for="">Description</label><br>
                            <textarea name="description" id=""placeholder="Description" >
                           
                            </textarea><br><br>
                    
                            <input type="submit" name="save" value="Save">
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <!-- editer -->
        <script>
            CKEDITOR.replace( 'description' );
        </script>

<!--- time ---->
    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>




</body>
</html>



