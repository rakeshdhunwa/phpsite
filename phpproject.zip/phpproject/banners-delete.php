<?php
    include_once('config.php');

    try{
        $id = $_REQUEST['id'];
        if($id){
            $bannerDelete = "DELETE FROM `banners` WHERE id=$id";
            $conn->query($bannerDelete);
            header('location:banners-list.php');
            $_SESSION['success'] = "Data Delete Successfully....";
        }else{
            header('location:banners-list.php');
            $_SESSION['error'] = "Error....";
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }





?>