<?php 
    include_once('config.php');
    $selectPage = " SELECT * FROM `pages`";
    $pageQuery = $conn->query($selectPage);
?>
<header>
       <a href="http://localhost/learnphp/phpproject/home.php"> <img src="img/logo-1.png" alt=""></a>
       <?php 
            while($pageData = $pageQuery->fetch_assoc()){
       ?>   
            <ul>
                <li><a href="<?=$pageData['url'];?>"><?=$pageData['name'];?></a></li>
            </ul>
    <?php
    }
    ?>
        <div class="header-right">
           <ul>
                <li>
                    <a href="mailto:rakesh@.com">rakesh@dhunwa.com</a><br>
                    <a href="tel:+91 8302825040">+91 8302825040</a>
                </li>
            </ul>		
        </div>
</header>